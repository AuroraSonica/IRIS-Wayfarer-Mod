IRIS - Lioness and Panther  v3.2  (build 20260815-1523)
================================================

Replaces BOTH wild cat variants on the redwolf chassis (ch223001_00 Puma /
ch223001_01 Panther) with a re-rigged lioness mesh.

WHAT IS IN THE PAK
  natives/stm/character/ch/ch23_001/     lioness mesh + 7 textures  (both cats)
  natives/stm/character/ch/ch23_002/     ch23_002.mdf2 + 7 charcoal textures (Panther)
  natives/stm/streaming/... /ch23_001/   streaming twins
  natives/stm/streaming/... /ch23_002/   streaming twins

HOW THE PANTHER GETS ITS OWN LOOK
  Both cats share one MESH (identical geometry), so the Panther only needs its own
  MATERIAL. IrisWildCats.lua pins ch23_002.mdf2 at arm, waits out a 15 s stream gate,
  builds a holder and calls set_Material on each live panther - the same runtime-swap
  route IrisWildHorses uses for the unicorn. That gives the Panther a real charcoal coat
  (relative contrast 0.61 vs the 0.21 a BaseColor tint can reach), its own eye atlas with
  a painted gold iris, and Emissive_Color1/2 baked yellow in the mdf2 itself.
  If the pak or the resource is missing it falls back to the old BaseColor tint, so a
  missing pak degrades the look rather than producing a tawny panther.

  ⛔ NOT DONE BY PATCHING ch223001_01.pfb. v2.x redirected that prefab at ch23_002 and it
  never reached get_Ready across four builds - an in-game probe proved the pak was fine
  (ch23_002.mesh=OK, no staging error), the prefab itself simply refused. Nothing in this
  install has ever shipped a patched prefab; the runtime swap is the proven mechanism.

UNINSTALL FIRST
  ALL earlier IRIS_Lioness / IRIS_LionessPanther builds are superseded.
  Fluffy can leave orphaned patch paks behind on uncheck - if the cat looks wrong,
  hash the deployed re_chunk_000.pak.patch_0XX.pak against the md5 in BUILD.txt.

CREDIT (REQUIRED - the source model is CC-BY)
  "Lioness - realistic 3D model demo", Sketchfab.

KNOWN LIMITS
  - Ears are damped to 45%: her ears sit 0.33 m behind the wolf's ear bones, so an
    undamped flick spiked to 4.8x edge stretch.
  - head/fur/angryhead materials are 1 mm dummy submeshes; those slots exist only to
    satisfy the fallback-material law and still point at vanilla textures.
  - Fur is derived from the albedo's high-pass; the source ships no normal map.
